'''
Created on Jun 28, 2015
Ch04
@author: Burkhard
'''
#======================
# imports
#======================

import tkinter as tk

# Create instance of tkinter
win = tk.Tk()

# Print out the default tkinter variable values
intData = tk.IntVar()
print(intData.get())

# Set a breakpoint here to see the values in the debugger
print() 



