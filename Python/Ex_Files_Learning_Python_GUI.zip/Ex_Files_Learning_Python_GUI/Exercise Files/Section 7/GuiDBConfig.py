'''
Created on Aug 4, 2015

@author: Burkhard
'''

# create dictionary to hold connection info
dbConfig = {
    'user': 'Admin',
    'password': 'admin',
    'host': '127.0.0.1',
    }



