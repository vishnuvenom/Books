'''
Created on Jun 20, 2015
Ch03
@author: Burkhard
'''
### SCREENSHOT 7 ##############################
from tkinter import messagebox as mBox
from tkinter import Tk
root = Tk()
root.withdraw()
mBox.showinfo('', 'A Python GUI created using tkinter:\nThe year is 2015')



