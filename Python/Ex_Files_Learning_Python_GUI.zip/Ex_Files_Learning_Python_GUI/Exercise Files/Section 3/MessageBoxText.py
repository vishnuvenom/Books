'''
Created on Jun 20, 2015
Ch03
@author: Burkhard
'''
### SCREENSHOT 6 ##############################
from tkinter import messagebox as mBox
mBox.showinfo('', 'A Python GUI created using tkinter:\nThe year is 2015')



